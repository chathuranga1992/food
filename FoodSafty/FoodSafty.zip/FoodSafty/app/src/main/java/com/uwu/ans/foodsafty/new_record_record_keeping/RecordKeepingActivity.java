package com.uwu.ans.foodsafty.new_record_record_keeping;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.uwu.ans.foodsafty.R;

public class RecordKeepingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_keeping);
    }
}
