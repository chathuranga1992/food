package com.uwu.ans.foodsafty.new_record_waste_management;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.uwu.ans.foodsafty.R;

public class WasteManagementActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_waste_management);
    }
}
