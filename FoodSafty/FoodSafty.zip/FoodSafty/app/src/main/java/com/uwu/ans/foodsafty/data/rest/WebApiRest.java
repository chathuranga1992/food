package com.uwu.ans.foodsafty.data.rest;

/**
 * Created by Rukshan on 4/29/19.
 */

interface WebApiRest {

}
