package com.uwu.ans.foodsafty.reports;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.uwu.ans.foodsafty.R;

public class ReportActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);
    }
}
