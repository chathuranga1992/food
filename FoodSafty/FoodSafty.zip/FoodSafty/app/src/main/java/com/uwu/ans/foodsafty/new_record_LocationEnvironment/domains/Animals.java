
package com.uwu.ans.foodsafty.new_record_LocationEnvironment.domains;


@SuppressWarnings("unused")
public class Animals {


    private String mDogCats;
    private String mOther;
    private String mMarks;
    private String mRemarks;

    public Animals(String mDogCats, String mOther, String mMarks, String mRemarks) {
        this.mDogCats = mDogCats;
        this.mOther = mOther;
        this.mMarks = mMarks;
        this.mRemarks = mRemarks;
    }

    public String getmDogCats() {
        return mDogCats;
    }

    public void setmDogCats(String mDogCats) {
        this.mDogCats = mDogCats;
    }

    public String getmOther() {
        return mOther;
    }

    public void setmOther(String mOther) {
        this.mOther = mOther;
    }

    public String getmMarks() {
        return mMarks;
    }

    public void setmMarks(String mMarks) {
        this.mMarks = mMarks;
    }

    public String getmRemarks() {
        return mRemarks;
    }

    public void setmRemarks(String mRemarks) {
        this.mRemarks = mRemarks;
    }
}
