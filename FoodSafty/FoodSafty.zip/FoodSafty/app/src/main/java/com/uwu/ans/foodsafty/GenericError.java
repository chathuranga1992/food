package com.uwu.ans.foodsafty;

/**
 * Created by Rukshan on 5/6/19.
 */

public abstract class GenericError {
    public abstract void error(Throwable t);
}
