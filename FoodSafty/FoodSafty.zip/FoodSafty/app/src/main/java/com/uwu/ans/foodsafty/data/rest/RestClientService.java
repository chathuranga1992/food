package com.uwu.ans.foodsafty.data.rest;



import java.util.Map;

/**
 * Created by Rukshan on 4/29/19.
 */

public interface RestClientService {

    void setToken(String mToken);

}
