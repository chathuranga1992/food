package com.uwu.ans.foodsafty.new_record_packaging_materials;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.uwu.ans.foodsafty.R;

public class PackagingMaterialActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_packaging_material);
    }
}
