package com.uwu.ans.foodsafty.profile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.uwu.ans.foodsafty.R;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
    }
}
