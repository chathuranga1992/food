package com.uwu.ans.foodsafty.facade;



import java.util.List;
import java.util.Map;

/**
 * Created by Rukshan on 4/29/19.
 */

public interface ISystemFacade {

//    void getChatToken(Map<String, String> param);
//
//    void saveChatToken(String token);
//
//    void loginUser(Map<String, String> parameters);
//
//    void userEventBadges(String eId);
//
//    void userEventRaffles(String eId);
//
//    void setToken(String token);
//
//    void setEventId(String eId);
//
//    void registerUser(Map<String, String> parameters);
//
//    void resetPassword(Map<String, String> parameters);
//
//    void setPicUpload(String path, String eventId, String badgeId, String caption, boolean isProfile);
//
//    void earnMasterCastleBadgeId(String id);
//
//    void InfoUser();
//
//    void UpdateUser(Map<String, String> parameters);
//
//    void logoutUser(Map<String, String> parameters);
//
////    NavigationItems getNavMenuItem();
////
////    SettingItem getSettingItem();
//
//    String getChatToken();
//
//    String getTUserId();
//
//    String getEId();
//
//    String getTokenType();
//
//    void setTokenType(String token);
//
////    BadgeItems getBadgesListItem();
//
//    boolean isAuthenticated();
//
//    void getAllGuests(Map<String, String> params);
//
//    void clearPreference();
//
//    //void getAllGuests(String id, Map<String, String> params);
//
////    long insertData(UserDataModel user);
////
////    long insertData(BadgeDataModel badge);
////
////    List<BadgeDataModel> getBadges();
////
////    UserDataModel getUser();
//
//    String getUserId();
//
//    void setUserId(String id);
//
//    String getUserName();
//
//    void setUserName(String name);
//
//    String getBio();
//
//    void setBio(String bio);
//
//    String getAddress();
//
//    void setAddress(String gender);
//
//    String getGender();
//
//    void setGender(String gender);
////
////    long insertData(ItineraryDataModel dataModel);
////
////    Event getItineraryData();
//
//    void setProfilePicture(String imgPath);
//
//    String getProfilePic();
//
//    void getGallaryData(Map<String, String> params);
//
//    void blockUser(String id);
//
//    void unblockUser(String id);
//
//    String getPpBatchId();
//
//    void setPpBatchId(String id);
//
//    String getFlightPhotoBatchId();
//
//    void setFlightPhotoBatchId(String id);
//
//    String getLitUpByArtBatchId();
//
//    void setLitUpByArtBatchId(String id);
//
//    String getMasterCastleBatchId();
//
//    void setMasterCastleBatchId(String id);
//
//    String getGroupPhotoBatchId();
//
//    void setGroupPhotoBatchId(String id);
//
//    boolean getPPBadgeStatus();
//
//    boolean isProfilePicBadgeEarned();
//
//    void setPPBadgeStatus(String ppBadgeStatus);
//
//    boolean getFlightPhotoBatchStatus();
//
//    void setFlightPhotoBatchStatus(String fpBadgeStatus);
//
//    boolean getLitUpByArtBatchStatus();
//
//    void setLitUpByArtBatchStatus(String lubaBadgeStatus);
//
//    boolean getMasterCastleBatchStatus();
//
//    void setMasterCastleBatchStatus(String mcBadgeStatus);
//
//    boolean getGroupPhotoBatchStatus();
//
//    void setGroupPhotoBatchStatus(String gpBadgeStatus);
//
//    boolean setGroupPhotoBatchStatus();
//
//    void addTagToImage(String id, String data);
//
//    void getUserDataById(String id);
//
//    String getTicketsCount();
//
//    void setTicketsCount(String count);
//
//    void updateRaffleEntry(String id, int count);
//
//    void deleteRaffleEntry(String id);
//
//    void getUserGifts();
//
//    void getAllRaffles();
//
//    String getLitUpByArtBatchPic();
//
//    void setLitUpByArtBatchPic(String pic);
//
//    String getGroupPhotoBatchPic();
//
//    void setGroupPhotoBatchPic(String pic);
//
//    String getFlightPhotoBatchPic();
//
//    void setFlightPhotoBatchPic(String pic);
//
//    String getProfilePhotoBatchPic();
//
//    void setProfilePhotoBatchPic(String pic);
//
//    String getMasterCastleBatchPic();
//
//    void setMasterCastleBatchPic(String pic);
//
////    void confirmGiftSelection(GiftRequest request);
//
//    void removeEarning(String id);
//
//    String getFCMToken();
//
//    boolean isTypeUser();
//
//    String getProfilePhotoBatchName();
//
//    void setProfilePhotoBatchName(String name);
//
//    String getLitUpByArtBatchName();
//
//    void setLitUpByArtBatchName(String name);
//
//    String getGroupPhotoBatchName();
//
//    void setGroupPhotoBatchName(String name);
//
//    String getFlightPhotoBatchName();
//
//    void setFlightPhotoBatchName(String name);
//
//    String getMasterCastleBatchName();
//
//    void setMasterCastleBatchName(String name);
//
//    String getProfilePhotoBatchDiscription();
//
//    void setProfilePhotoBatchDiscription(String Discription);
//
//    String getLitUpByArtBatchDiscription();
//
//    void setLitUpByArtBatchDiscription(String Discription);
//
//    String getGroupPhotoBatchDiscription();
//
//    void setGroupPhotoBatchDiscription(String Discription);
//
//    String getFlightPhotoBatchDiscription();
//
//    void setFlightPhotoBatchDiscription(String Discription);
//
//    String getMasterCastleBatchDiscription();
//
//    void setMasterCastleBatchDiscription(String Discription);
//
//    void attemptFetchAdvertistment(String type);

}
